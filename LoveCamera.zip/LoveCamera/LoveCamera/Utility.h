//
//  Utility.h
//  LoveCamera
//
//  Created by Rain on 16/3/18.
//  Copyright © 2016年 Rain. All rights reserved.
//

#ifndef Utility_h
#define Utility_h

#define kMainScreenWidth [UIScreen mainScreen].bounds.size.width
#define kMainScreenHeight  [UIScreen mainScreen].bounds.size.height

#endif /* Utility_h */
