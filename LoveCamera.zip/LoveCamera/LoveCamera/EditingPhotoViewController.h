//
//  EditingPhotoViewController.h
//  LoveCamera
//
//  Created by Rain on 16/3/19.
//  Copyright © 2016年 Rain. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditingPhotoViewController : UIViewController

@property (nonatomic, strong) NSData *editingImageData;
@property (nonatomic, assign) BOOL isFront;

@end
